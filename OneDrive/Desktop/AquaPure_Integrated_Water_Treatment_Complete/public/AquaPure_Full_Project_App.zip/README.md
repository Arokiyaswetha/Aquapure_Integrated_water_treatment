# AquaPure Flask API

Mirrors the TypeScript predictors used in the AquaPure web app.

## Run

    pip install flask flask-cors
    python app.py

## Endpoints
- POST /api/predict            (Pipeline A: Potability, WQI, SHAP, WHO compliance)
- POST /api/predict-effluent   (Pipeline B: Effluent BOD/COD/TSS, CPCB reuse)
- POST /api/predict-maintenance (Failure risk %, RUL, component isolation)
- POST /api/predict-nutrients  (Struvite kg/day, N & P %, revenue)
- GET  /api/metrics            (9-model benchmark matrix)
- GET  /download               (Serves this ZIP)
