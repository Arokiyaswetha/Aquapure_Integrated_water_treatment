from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os, math

app = Flask(__name__)
CORS(app)

WHO = {
  "ph": (6.5, 8.5), "hardness": (0, 300), "solids": (0, 1000),
  "chloramines": (0, 4), "sulfate": (0, 250), "conductivity": (0, 800),
  "organic_carbon": (0, 4), "trihalomethanes": (0, 80), "turbidity": (0, 5),
}
W = {"ph":15,"hardness":8,"solids":15,"chloramines":12,"sulfate":8,
     "conductivity":10,"organic_carbon":10,"trihalomethanes":12,"turbidity":10}

@app.post("/api/predict")
def predict():
    x = request.get_json(force=True)
    total, shap, comp = 0, [], []
    for k,(lo,hi) in WHO.items():
        v = float(x.get(k, 0))
        ok = lo <= v <= hi
        dev = 0 if ok else min(1, (lo-v)/max(lo,1) if v<lo else (v-hi)/max(hi,1))
        s = W[k]*(1-dev); total += s
        shap.append({"feature":k,"impact":round(s-W[k]*0.5,2),"direction":"positive" if ok else "negative"})
        comp.append({"feature":k,"value":v,"limit":f"{lo}-{hi}","ok":ok})
    wqi = max(0, min(100, total/sum(W.values())*100))
    potable = wqi >= 70 and all(c["ok"] for c in comp)
    shap.sort(key=lambda s: abs(s["impact"]), reverse=True)
    return jsonify({"potable":potable,"wqi":round(wqi,1),
                    "verdict":"SAFE TO DRINK" if potable else "CONTAMINATED",
                    "shap":shap,"compliance":comp})

@app.post("/api/predict-effluent")
def eff():
    x = request.get_json(force=True)
    q,b,c,s = float(x["flow_q_e"]),float(x["bod_e"]),float(x["cod_e"]),float(x["ss_e"])
    lf = min(1.3, q/100 + 0.6)
    eb,ec,et = round(b*(1-0.96/lf),1), round(c*(1-0.90/lf),1), round(s*(1-0.97/lf),1)
    cats = {"A":(10,50,10),"B":(20,100,20),"C":(30,150,50)}
    cat = "D"
    for k,(bl,cl,tl) in cats.items():
        if eb<=bl and ec<=cl and et<=tl: cat=k; break
    names = {"A":"Category A - Agricultural Crop Irrigation","B":"Category B - Industrial Cooling & Process Reuse",
             "C":"Category C - Urban Parks / Landscape","D":"Category D - Non-Compliant / Requires Retreatment"}
    return jsonify({"effluent":{"bod":eb,"cod":ec,"tss":et},
        "removal":{"bod":round((1-eb/b)*100,1),"cod":round((1-ec/c)*100,1),"tss":round((1-et/s)*100,1)},
        "category":cat,"reuse":names[cat]})

@app.post("/api/predict-maintenance")
def maint():
    x = request.get_json(force=True)
    tmp=min(1,max(0,(float(x["tmp"])-0.3)/1.2))
    vib=min(1,float(x["vibration"])/11.2)
    tp=min(1,max(0,(float(x["motor_temp"])-55)/45))
    fd=min(1,float(x["flow_drop"])/40)
    wr=min(1,float(x["operating_hours"])/40000)
    risk = 100*(0.28*tmp+0.28*vib+0.18*tp+0.16*fd+0.10*wr)
    status = "HEALTHY" if risk<25 else "MONITOR" if risk<50 else "WARNING" if risk<75 else "CRITICAL"
    return jsonify({"failure_risk":round(risk,1),"status":status,
                    "rul_hours":max(24,int(8000*(1-risk/100))),
                    "components":[
                      {"name":"MBR Membrane","risk":round(tmp*100)},
                      {"name":"Pump Bearing","risk":round(vib*100)},
                      {"name":"Blower Motor","risk":round(tp*100)},
                      {"name":"Piping","risk":round(fd*100)},
                      {"name":"General Wear","risk":round(wr*100)}]})

@app.post("/api/predict-nutrients")
def nut():
    x = request.get_json(force=True)
    mN=float(x["nh3_n"])/14; mP=float(x["po4_p"])/31; mMg=float(x["mg"])/24.3
    lim=min(mN,mP,mMg); ph=float(x["ph"])
    phEff = 0.3 if ph<7.5 else 0.55 if ph>10.5 else min(1, 1-abs(ph-9)/2)
    kg = lim*0.2454*float(x["daily_flow"])*1000*phEff
    return jsonify({"struvite_kg_day":round(kg,1),
                    "n_recovery":round(min(95, phEff*92),1),
                    "p_recovery":round(min(95, phEff*94),1),
                    "revenue_usd_day":round(kg*0.55,2)})

@app.get("/api/metrics")
def metrics():
    return jsonify([
      {"model":"MLP Neural Network","accuracy":66.77,"auc":0.6718,"f1":0.5910},
      {"model":"Stacking Ensemble","accuracy":66.31,"auc":0.6689,"f1":0.5847},
      {"model":"Voting Ensemble","accuracy":65.84,"auc":0.6612,"f1":0.5772},
      {"model":"LightGBM","accuracy":63.15,"auc":0.6402,"f1":0.5336},
      {"model":"Random Forest","accuracy":62.42,"auc":0.6318,"f1":0.5241},
      {"model":"XGBoost","accuracy":62.09,"auc":0.6283,"f1":0.5198},
      {"model":"K-Nearest Neighbors","accuracy":59.66,"auc":0.5942,"f1":0.4820},
      {"model":"Support Vector Machine","accuracy":58.87,"auc":0.5828,"f1":0.4712},
      {"model":"Logistic Regression","accuracy":57.34,"auc":0.5691,"f1":0.4523},
    ])

@app.get("/download")
def download():
    return send_file(os.path.abspath(__file__).replace("app.py","AquaPure_Full_Project_App.zip"), as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
